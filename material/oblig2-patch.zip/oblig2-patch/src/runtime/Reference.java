package runtime;

public class Reference {
	private int address;
	public Reference(int address){
		this.address = address;
	}
	public int getAddress() {
		return address;
	}
}
