package runtime;

public class NullReference {
	public static final NullReference NULL = new NullReference();
	private NullReference(){}
}
